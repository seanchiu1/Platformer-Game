About:

This game is a platformer game that you have to collect all the coins in order to win. This game focuses on speedrunning where the game records the time it takes for you to pass. If you fall off the map or get touched by the spider, you lose a life. You can get sticky on the wall. 

Contribution:

Video coding: 50% Sean 50% Nico

Map: Nico

Debug and Timer: Sean

